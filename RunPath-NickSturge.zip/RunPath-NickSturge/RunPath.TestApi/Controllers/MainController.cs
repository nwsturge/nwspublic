﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RunPath.TestApi.Services.DTOs;
using RunPath.TestApi.Services.Interface;

namespace RunPath.TestApi.Controllers
{
    public class MainController : Controller
    {
        private readonly IAlbumRetriever _albumRetriever;

        public MainController(IAlbumRetriever albumRetriever)
        {
            _albumRetriever = albumRetriever;
        }

        [HttpGet]
        [Route("main/helloworld")]
        public string HelloWorld()
        {
            return "Hello world";
        }

        [HttpGet]
        [Route("main/albums")]
        public async Task<List<AlbumWithContents>> GetAlbums(int? userId = null)
        {
            var result = await _albumRetriever.Go(userId);
            return result;
        }
    }
}
