﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using RunPath.TestApi.Services.Implementation;
using RunPath.TestApi.Services.Interface;

namespace RunPath.TestApi.Tests
{
    [TestClass]
    public class AlbumRetrieverTests
    {
        [TestMethod]
        public async Task TestFull()
        {
            var sut = new AlbumRetriever(new MockFetcher());

            var result = await sut.Go();

            Assert.AreEqual(3, result.Count);
            var album1 = result.FirstOrDefault(a => a.id == 1);
            Assert.AreEqual(2, album1.photos.Count);
        }

        [TestMethod]
        public async Task TestFilter()
        {
            var sut = new AlbumRetriever(new MockFetcher());

            var result = await sut.Go(1);

            Assert.AreEqual(2, result.Count);
            var album1 = result.FirstOrDefault(a => a.id == 1);
            Assert.AreEqual(2, album1.photos.Count);

            var albumForOtherUser = result.FirstOrDefault(a => a.userId != 1);
            Assert.AreEqual(null, albumForOtherUser);
        }

        // A longer-term solution would be to use a mocking library; it's not necessary for this simple case.
        private class MockFetcher : IFetchFromUrl
        {
            public Task<T> Go<T>(string url)
            {
                string json;
                if (url == "http://jsonplaceholder.typicode.com/albums")
                {
                    json = @"
[
  {
    ""userId"": 1,
    ""id"": 1,
    ""title"": ""quidem molestiae enim""
  },
  {
    ""userId"": 1,
    ""id"": 2,
    ""title"": ""sunt qui excepturi placeat culpa""
  },
  {
    ""userId"": 2,
    ""id"": 3,
    ""title"": ""omnis laborum odio""
  },
]
";
                }
                else if (url == "http://jsonplaceholder.typicode.com/photos")
                {
                    json = @"
[
  {
    ""albumId"": 1,
    ""id"": 1,
    ""title"": ""accusamus beatae ad facilis cum similique qui sunt"",
    ""url"": ""https://via.placeholder.com/600/92c952"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/92c952""
  },
  {
    ""albumId"": 1,
    ""id"": 2,
    ""title"": ""reprehenderit est deserunt velit ipsam"",
    ""url"": ""https://via.placeholder.com/600/771796"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/771796""
  },
  {
    ""albumId"": 2,
    ""id"": 3,
    ""title"": ""officia porro iure quia iusto qui ipsa ut modi"",
    ""url"": ""https://via.placeholder.com/600/24f355"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/24f355""
  },
  {
    ""albumId"": 3,
    ""id"": 4,
    ""title"": ""culpa odio esse rerum omnis laboriosam voluptate repudiandae"",
    ""url"": ""https://via.placeholder.com/600/d32776"",
    ""thumbnailUrl"": ""https://via.placeholder.com/150/d32776""
  }
]
                ";
                }
                else
                    throw new Exception("MockFetcher: unrecognised url " + url);

                var result = JsonConvert.DeserializeObject<T>(json);
                return Task.FromResult(result);
            }
        }
    }
}
