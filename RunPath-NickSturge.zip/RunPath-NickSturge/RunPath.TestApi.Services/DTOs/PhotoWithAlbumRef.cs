﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunPath.TestApi.Services.DTOs
{
    internal class PhotoWithAlbumRef : Photo
    {
        public int albumId { get; set; }
    }
}
