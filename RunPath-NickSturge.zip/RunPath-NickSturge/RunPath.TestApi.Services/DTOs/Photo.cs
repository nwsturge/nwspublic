﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunPath.TestApi.Services.DTOs
{
    public class Photo
    {
        public int id { get; set; }
        public string title { get; set; }
        public string url { get; set; }
        public string thumbnailUrl { get; set; }

        public static Photo Clone(Photo arg)
        {
            return new Photo
            {
                id = arg.id,
                title = arg.title,
                url = arg.url,
                thumbnailUrl = arg.thumbnailUrl
            };
        }
    }
}
