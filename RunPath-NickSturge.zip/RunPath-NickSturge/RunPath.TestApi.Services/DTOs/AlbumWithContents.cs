﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunPath.TestApi.Services.DTOs
{
    public class AlbumWithContents : AlbumHeader
    {
        public List<Photo> photos { get; set; }

        public static AlbumWithContents Create(AlbumHeader header)
        {
            return new AlbumWithContents
            {
                userId = header.userId,
                id = header.id,
                title = header.title,
                photos = new List<Photo>()
            };
        }
    }
}
