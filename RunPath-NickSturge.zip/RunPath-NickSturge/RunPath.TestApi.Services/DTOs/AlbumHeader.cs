﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunPath.TestApi.Services.DTOs
{
    public class AlbumHeader
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
    }
}
