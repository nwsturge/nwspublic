﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using RunPath.TestApi.Services.Implementation;
using RunPath.TestApi.Services.Interface;

namespace RunPath.TestApi.Services
{
    public static class RegisterImplementations
    {
        public static void Go(IServiceCollection serviceCollection)
        {
            serviceCollection.AddSingleton<IFetchFromUrl, FetchJsonOverHttp>();
            serviceCollection.AddSingleton<IAlbumRetriever, AlbumRetriever>();
        }
    }
}
