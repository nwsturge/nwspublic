﻿using RunPath.TestApi.Services.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RunPath.TestApi.Services.Interface
{
    public interface IAlbumRetriever
    {
        Task<List<AlbumWithContents>> Go(int? userId = null);
    }
}
