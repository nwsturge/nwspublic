﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RunPath.TestApi.Services.Interface
{
    public interface IFetchFromUrl
    {
        Task<T> Go<T>(string url);
    }
}
