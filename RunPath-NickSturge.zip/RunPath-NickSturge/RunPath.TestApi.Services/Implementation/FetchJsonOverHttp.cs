﻿using Newtonsoft.Json;
using RunPath.TestApi.Services.Interface;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace RunPath.TestApi.Services.Implementation
{
    internal class FetchJsonOverHttp : IFetchFromUrl
    {
        static readonly HttpClient httpClient = new HttpClient();

        public async Task<T> Go<T>(string url)
        {
            // I feel there should be some error-handling here, I would need to clarify the requirements to decide what would be appropriate.
            // Some logging may also be appropriate.

            var httpResponse = await httpClient.GetAsync(url);

            var contentStr = await httpResponse.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<T>(contentStr);

            return result;
        }
    }
}
