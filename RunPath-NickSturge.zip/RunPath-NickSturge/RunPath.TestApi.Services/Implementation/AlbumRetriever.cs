﻿using RunPath.TestApi.Services.DTOs;
using RunPath.TestApi.Services.Interface;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

[assembly: InternalsVisibleTo("RunPath.TestApi.Tests")]


namespace RunPath.TestApi.Services.Implementation
{
    internal class AlbumRetriever : IAlbumRetriever
    {
        private readonly IFetchFromUrl _fetcher;

        public AlbumRetriever(IFetchFromUrl fetcher)
        {
            _fetcher = fetcher;
        }

        // I prefer returning List rather than IEnumerable to avoid giving the impression that the result might be lazily-evaluated.
        public async Task<List<AlbumWithContents>> Go(int? userId = null)
        {
            // Should probably get URLs from some configuration.  AppSettings might be appropriate, another way to go would be to store config in a database.  Likely release cadence may impact this decision.
            var albumUrl = "http://jsonplaceholder.typicode.com/albums";
            var photoUrl = "http://jsonplaceholder.typicode.com/photos";

            var albumHeaders = await _fetcher.Go<List<AlbumHeader>>(albumUrl);
            var photos = await _fetcher.Go<List<PhotoWithAlbumRef>>(photoUrl);

            if (userId.HasValue)
            {
                albumHeaders = albumHeaders.Where(h => h.userId == userId.Value).ToList();
            }

            var result = Combine(albumHeaders, photos);

            return result;
        }

        internal List<AlbumWithContents> Combine(List<AlbumHeader> albumHeaders, List<PhotoWithAlbumRef> photos)
        {
            var resultAccumulator = new Dictionary<int, AlbumWithContents>();
            albumHeaders.ForEach(h => resultAccumulator.Add(h.id, AlbumWithContents.Create(h)));

            photos.ForEach(p =>
            {
                AlbumWithContents album;
                if (resultAccumulator.TryGetValue(p.albumId, out album))
                    album.photos.Add(Photo.Clone(p));
            });

            return resultAccumulator.Values.ToList();
        }
    }
}
